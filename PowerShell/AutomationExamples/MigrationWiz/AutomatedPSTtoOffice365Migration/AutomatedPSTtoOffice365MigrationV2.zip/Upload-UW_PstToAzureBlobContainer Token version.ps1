﻿<#

.SYNOPSIS

88888888ba   88      888888888888  88                                            88                                
88      "8b  ""    ,d     88       ""    ,d                                      88                                
88      ,8P        88     88             88                                      88                                
88aaaaaa8P'  88  MM88MMM  88       88  MM88MMM  ,adPPYYba,  8b,dPPYba,           88  8b,dPPYba,    ,adPPYba,       
88""""""8b,  88    88     88       88    88     ""     `Y8  88P'   `"8a          88  88P'   `"8a  a8"     ""       
88      `8b  88    88     88       88    88     ,adPPPPP88  88       88          88  88       88  8b               
88      a8P  88    88,    88       88    88,    88,    ,88  88       88  "88     88  88       88  "8a,   ,aa  888  
88888888P"   88    "Y888  88       88    "Y888  `"8bbdP"Y8  88       88  d8'     88  88       88   `"Ybbd8"'  888  
                                                                        8"                                         
© Copyright 2018 BitTitan, Inc. All Rights Reserved.


.DESCRIPTION
    This script will create an Azure blob container in case it does not exist and a .bat file that will be sent automatically to all end users.
    as an email attachment. The email i sent from Office 365. The .bat file will have to be clicked by each end user to automatically donwload 
    the UploaderWiz agent from BitTitan server, disconnect all PST files from the Outlook profile and discover and upload all PST files to the 
    Azure blob container. The end users' email adddreses are read from a CSV file.
	
.NOTES
	Author			For any questions contact Technical Sales Specialist Team <TSTeam@bittitan.com> or the author of this script Pablo Galan Sabugo <pablog@bittitan.com> 
	Date		    Nov/2018
	Disclaimer: 	This script is provided 'AS IS'. No warrantee is provided either expressed or implied. 
    BitTitan cannot be held responsible for any misuse of the script.
    Version: 1.1
#>

# Function to create the working and log directories
Function Create-Working-Directory {    
    param 
    (
        [CmdletBinding()]
        [parameter(Mandatory=$true)] [string]$workingDir,
        [parameter(Mandatory=$true)] [string]$logDir
    )
    if ( !(Test-Path -Path $workingDir)) {
		try {
			$suppressOutput = New-Item -ItemType Directory -Path $workingDir -Force -ErrorAction Stop
            $msg = "SUCCESS: Folder '$($workingDir)' for CSV files has been created."
            Write-Host -ForegroundColor Green $msg
		}
		catch {
            $msg = "ERROR: Failed to create '$workingDir'. Script will abort."
            Write-Host -ForegroundColor Red $msg
            Exit
		}
    }
    if ( !(Test-Path -Path $logDir)) {
        try {
            $suppressOutput = New-Item -ItemType Directory -Path $logDir -Force -ErrorAction Stop      

            $msg = "SUCCESS: Folder '$($logDir)' for log files has been created."
            Write-Host -ForegroundColor Green $msg 
        }
        catch {
            $msg = "ERROR: Failed to create log directory '$($logDir)'. Script will abort."
            Write-Host -ForegroundColor Red $msg
            Exit
        } 
    }
}

# Function to write information to the Log File
Function Log-Write {
    param
    (
        [Parameter(Mandatory=$true)]    [string]$Message
    )
    $lineItem = "[$(Get-Date -Format "dd-MMM-yyyy HH:mm:ss") | PID:$($pid) | $($env:username) ] " + $Message
	Add-Content -Path $logFile -Value $lineItem
}

# Function to display the workgroups created by the user
Function Select-MSPC_Workgroup {

    #######################################
    # Display all mailbox workgroups
    #######################################

    $workgroupPageSize = 100
  	$workgroupOffSet = 0
	$workgroups = $null

    Write-Host
    Write-Host -Object  "INFO: Retrieving MSPC workgroups..."

    do
    {   try {
            $workgroupsPage = @(Get-BT_Workgroup  -PageOffset $workgroupOffSet -PageSize $workgroupPageSize) #-CreatedBySystemUserId $ticket.SystemUserId
        }
        catch {
            $msg = "ERROR: Failed to retrieve MSPC workgroups."
            Write-Host -ForegroundColor Red  $msg
            Log-Write -Message $msg
            Write-Host -ForegroundColor Red $_.Exception.Message
            Log-Write -Message $_.Exception.Message
            Exit
        }
    
        if($workgroupsPage) {
            $workgroups += @($workgroupsPage)
            foreach($Workgroup in $workgroupsPage) {
                Write-Progress -Activity ("Retrieving workgroups (" + $workgroups.Length + ")") -Status $Workgroup.Id
            }
            
            $workgroupOffset += $workgroupPageSize
        }

    } while($workgroupsPage)

    

    if($workgroups -ne $null -and $workgroups.Length -ge 1) {
        Write-Host -ForegroundColor Green -Object ("SUCCESS: "+ $workgroups.Length.ToString() + " Workgroup(s) found.") 
    }
    else {
        Write-Host -ForegroundColor Red -Object  "INFO: No workgroups found." 
        Exit
    }

    #######################################
    # Prompt for the mailbox Workgroup
    #######################################
    if($workgroups -ne $null)
    {
        Write-Host -ForegroundColor Yellow -Object "ACTION: Select a Workgroup:" 
        Write-Host -ForegroundColor Gray -Object "INFO: your default workgroup has no name, only Id." 

        for ($i=0; $i -lt $workgroups.Length; $i++)
        {
            $Workgroup = $workgroups[$i]
            if($Workgroup.Name -eq $null) {
                Write-Host -Object $i,"-",$Workgroup.Id
            }
            else {
                Write-Host -Object $i,"-",$Workgroup.Name
            }
        }
        Write-Host -Object "x - Exit"
        Write-Host

        do
        {
            if($workgroups.count -eq 1) {
                $msg = "INFO: There is only one workgroup. Selected by default."
                Write-Host -ForegroundColor yellow  $msg
                Log-Write -Message $msg
                $Workgroup=$workgroups[0]
                Return $Workgroup.Id
            }
            else {
                $result = Read-Host -Prompt ("Select 0-" + ($workgroups.Length-1) + ", or x")
            }
            
            if($result -eq "x")
            {
                Exit
            }
            if(($result -match "^\d+$") -and ([int]$result -ge 0) -and ([int]$result -lt $workgroups.Length))
            {
                $Workgroup=$workgroups[$result]
                Return $Workgroup.Id
            }
        }
        while($true)

    }

}

# Function to display all customers
Function Select-MSPC_Customer {

    param 
    (      
        [parameter(Mandatory=$true)] [String]$WorkgroupId
    )

    #######################################
    # Display all mailbox customers
    #######################################

    $customerPageSize = 100
  	$customerOffSet = 0
	$customers = $null

    Write-Host
    Write-Host -Object  "INFO: Retrieving MSPC customers..."

    do
    {   
        try { 
            $customersPage = @(Get-BT_Customer -WorkgroupId $WorkgroupId -IsDeleted False -IsArchived False -PageOffset $customerOffSet -PageSize $customerPageSize)
        }
        catch {
            $msg = "ERROR: Failed to retrieve MSPC customers."
            Write-Host -ForegroundColor Red  $msg
            Log-Write -Message $msg
            Write-Host -ForegroundColor Red $_.Exception.Message
            Log-Write -Message $_.Exception.Message
            Exit
        }
    
        if($customersPage) {
            $customers += @($customersPage)
            foreach($customer in $customersPage) {
                Write-Progress -Activity ("Retrieving customers (" + $customers.Length + ")") -Status $customer.CompanyName
            }
           
            $customerOffset += $customerPageSize
        }

    } while($customersPage)

    

    if($customers -ne $null -and $customers.Length -ge 1) {
        Write-Host -ForegroundColor Green -Object ("SUCCESS: "+ $customers.Length.ToString() + " customer(s) found.") 
    }
    else {
        Write-Host -ForegroundColor Red -Object  "INFO: No customers found." 
        Exit
    }

    #######################################
    # {Prompt for the mailbox customer
    #######################################
    if($customers -ne $null)
    {
        Write-Host -ForegroundColor Yellow -Object "ACTION: Select a customer:" 

        for ($i=0; $i -lt $customers.Length; $i++)
        {
            $customer = $customers[$i]
            Write-Host -Object $i,"-",$customer.CompanyName
        }
        Write-Host -Object "x - Exit"
        Write-Host

        do
        {
            if($customers.count -eq 1) {
                $msg = "INFO: There is only one customer. Selected by default."
                Write-Host -ForegroundColor yellow  $msg
                Log-Write -Message $msg
                $customer=$customers[0]
                Return $customer.OrganizationId
            }
            else {
                $result = Read-Host -Prompt ("Select 0-" + ($customers.Length-1) + ", or x")
            }

            if($result -eq "x")
            {
                Exit
            }
            if(($result -match "^\d+$") -and ([int]$result -ge 0) -and ([int]$result -lt $customers.Length))
            {
                $customer=$customers[$result]
                Return $Customer.OrganizationId
            }
        }
        while($true)

    }

}

# Function to display all endpoints under a customer
Function Select-MSPC_Endpoint {
    param 
    (      
        [parameter(Mandatory=$true)] [guid]$customerId,
        [parameter(Mandatory=$false)] [String]$endpointType,
        [parameter(Mandatory=$false)] [String]$endpointName,
        [parameter(Mandatory=$false)] [object]$endpointConfiguration,
        [parameter(Mandatory=$false)] [String]$exportOrImport,
        [parameter(Mandatory=$false)] [boolean]$deleteEndpointType

    )

    #####################################################################################################################
    # Display all MSPC endpoints. If $endpointType is provided, only endpoints of that type
    #####################################################################################################################

    $endpointPageSize = 100
  	$endpointOffSet = 0
	$endpoints = $null

    Write-Host
    if($endpointType -ne "") {
        Write-Host -Object  "INFO: Retrieving MSPC $exportOrImport $endpointType endpoints..."
    }else {
        Write-Host -Object  "INFO: Retrieving MSPC $exportOrImport endpoints..."
    }

    $customerTicket = Get-BT_Ticket -OrganizationId $customerId

    do {
        try{
            if($endpointType -ne "") {
                $endpointsPage = @(Get-BT_Endpoint -Ticket $customerTicket -IsDeleted False -IsArchived False -PageOffset $endpointOffSet -PageSize $endpointPageSize -type $endpointType)
            }else{
                $endpointsPage = @(Get-BT_Endpoint -Ticket $customerTicket -IsDeleted False -IsArchived False -PageOffset $endpointOffSet -PageSize $endpointPageSize)
            }
        }
        catch {
            $msg = "ERROR: Failed to retrieve MSPC endpoints."
            Write-Host -ForegroundColor Red  $msg
            Log-Write -Message $msg
            Write-Host -ForegroundColor Red $_.Exception.Message
            Log-Write -Message $_.Exception.Message
            Exit
        }

        if($endpointsPage) {
            
            $endpoints += @($endpointsPage)

            foreach($endpoint in $endpointsPage) {
                Write-Progress -Activity ("Retrieving endpoint (" + $endpoints.Length + ")") -Status $endpoint.Name
            }
            
            $endpointOffset += $endpointPageSize
        }
    } while($endpointsPage)

    Write-Progress -Activity " " -Completed

    if($endpoints -ne $null -and $endpoints.Length -ge 1) {
        Write-Host -ForegroundColor Green "SUCCESS: $($endpoints.Length) endpoint(s) found."
    }
    else {
        Write-Host -ForegroundColor Red "INFO: No endpoints found." 
    }

    #####################################################################################################################
    # Prompt for the endpoint. If no endpoints found and endpointType provided, ask for endpoint creation
    #####################################################################################################################
    if($endpoints -ne $null) {
        Write-Host -ForegroundColor Yellow -Object "ACTION: Select the $exportOrImport $endpointType endpoint:" 

        for ($i=0; $i -lt $endpoints.Length; $i++) {
            $endpoint = $endpoints[$i]
            Write-Host -Object $i,"-",$endpoint.Name
        }
        Write-Host -Object "c - Create a new $endpointType endpoint"
        Write-Host -Object "x - Exit"
        Write-Host

        do
        {
            if($endpoints.count -eq 1) {
                $result = Read-Host -Prompt ("Select 0, c or x")
            }
            else {
                $result = Read-Host -Prompt ("Select 0-" + ($endpoints.Length-1) + ", c or x")
            }
            if($result -eq "c") {
                if ($endpointName -eq "") {
                    $endpointId = create-MSPC_Endpoint -CustomerId $CustomerId -ExportOrImport $exportOrImport -EndpointType $endpointType -EndpointConfiguration $endpointConfiguration                  
                }
                else {
                    $endpointId = create-MSPC_Endpoint -CustomerId $CustomerId -ExportOrImport $exportOrImport -EndpointType $endpointType -EndpointConfiguration $endpointConfiguration -EndpointName $endpointName
                }
                Return $endpointId
            }
            if($result -eq "x") {
                Exit
            }
            if(($result -match "^\d+$") -and ([int]$result -ge 0) -and ([int]$result -lt $endpoints.Length)) {
                $endpoint=$endpoints[$result]
                Return $endpoint.Id
            }
        }
        while($true)

    } 
    elseif($endpoints -eq $null -and $endpointType -ne "") {

        do {
            $confirm = (Read-Host -prompt "Do you want to create a $endpointType endpoint ?  [Y]es or [N]o").trim()
        } while(($confirm.ToLower() -ne "y") -and ($confirm.ToLower() -ne "n"))

        if($confirm.ToLower() -eq "y") {
            if ($endpointName -eq "") {
                $endpointId = create-MSPC_Endpoint -CustomerId $CustomerId -ExportOrImport $exportOrImport -ExportOrImport $exportOrImport -EndpointType $endpointType -EndpointConfiguration $endpointConfiguration 
            }
            else {
                $endpointId = create-MSPC_Endpoint -CustomerId $CustomerId -ExportOrImport $exportOrImport -ExportOrImport $exportOrImport -EndpointType $endpointType -EndpointConfiguration $endpointConfiguration -EndpointName $endpointName
            }
            Return $endpointId
        }
    }
}

# Function to get endpoint data
 Function Get-MSPC_EndpointData {
    param 
    (      
        [parameter(Mandatory=$true)] [guid]$customerId,
        [parameter(Mandatory=$true)] [guid]$endpointId
    )

    $customerTicket  = Get-BT_Ticket -OrganizationId $customerId

    try {
        $endpoint = Get-BT_Endpoint -Ticket $customerTicket -Id $endpointId -IsDeleted False -IsArchived False  -ShouldUnmaskproperties $true | Select-Object -Property Name, Type -ExpandProperty Configuration
        
        $msg = "SUCCESS: Endpoint '$($endpoint.Name)' credentials retrieved." 
        write-Host -ForegroundColor Green $msg
        Log-Write -Message $msg 

        if($endpoint.Type -eq "AzureFileSystem") {

            $endpointCredentials = New-Object PSObject
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name Name -Value $endpoint.Name
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name AccessKey -Value $endpoint.AccessKey
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name ContainerName -Value $endpoint.ContainerName
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name AdministrativeUsername -Value $endpoint.AdministrativeUsername

            return $endpointCredentials        
        }
        
        elseif($endpoint.Type -eq "Pst") {

            $endpointCredentials = New-Object PSObject
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name Name -Value $endpoint.Name
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name AccessKey -Value $endpoint.AccessKey
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name ContainerName -Value $endpoint.ContainerName
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name AdministrativeUsername -Value $endpoint.AdministrativeUsername

            return $endpointCredentials        
        }
        elseif($endpoint.Type -eq "OneDriveProAPI"){
            $endpointCredentials = New-Object PSObject
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name Name -Value $endpoint.Name
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name UseAdministrativeCredentials -Value $endpoint.UseAdministrativeCredentials
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name AdministrativeUsername -Value $endpoint.AdministrativeUsername
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name AdministrativePassword -Value $endpoint.AdministrativePassword
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name AzureStorageAccountName -Value $endpoint.AzureStorageAccountName
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name AzureAccountKey -Value $endpoint.AzureAccountKey

            return $endpointCredentials   
        }
        elseif($endpoint.Type -eq "Office365Groups"){
            
            $endpointCredentials = New-Object PSObject
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name Name -Value $endpoint.Name
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name Url -Value $endpoint.Url
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name UseAdministrativeCredentials -Value $endpoint.UseAdministrativeCredentials
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name AdministrativeUsername -Value $endpoint.AdministrativeUsername
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name AdministrativePassword -Value $endpoint.AdministrativePassword

            return $endpointCredentials     
        }
        elseif($endpoint.Type -eq "ExchangeOnline2"){
            $endpointCredentials = New-Object PSObject
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name Name -Value $endpoint.Name
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name UseAdministrativeCredentials -Value $endpoint.UseAdministrativeCredentials
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name AdministrativeUsername -Value $endpoint.AdministrativeUsername
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name AdministrativePassword -Value $endpoint.AdministrativePassword

            return $endpointCredentials  
        }
        elseif($endpoint.Type -eq "AzureSubscription"){
            $endpointCredentials = New-Object PSObject
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name Name -Value $endpoint.Name
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name UseAdministrativeCredentials -Value $endpoint.UseAdministrativeCredentials
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name AdministrativeUsername -Value $endpoint.AdministrativeUsername
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name AdministrativePassword -Value $endpoint.AdministrativePassword
            $endpointCredentials | Add-Member -MemberType NoteProperty -Name SubscriptionID -Value $endpoint.SubscriptionID

            return $endpointCredentials
        
        }
    }
    catch {
        $msg = "ERROR: Failed to retrieve endpoint '$($endpoint.Name)' credentials."
        Write-Host -ForegroundColor Red  $msg
        Log-Write -Message $msg
    }
 }

 # Function to create an endpoint under a customer
# Configuration Table in https://www.bittitan.com/doc/powershell.html#PagePowerShellmspcmd%20
Function create-MSPC_Endpoint {
    param 
    (      
        [parameter(Mandatory=$true)] [guid]$CustomerId,
        [parameter(Mandatory=$false)] [String]$endpointType,
        [parameter(Mandatory=$false)] [String]$endpointName,
        [parameter(Mandatory=$false)] [object]$endpointConfiguration,
        [parameter(Mandatory=$false)] [String]$exportOrImport
    )

    $customerTicket  = Get-BT_Ticket -OrganizationId $customerId

    if($endpointType -eq "AzureFileSystem"){
        
        #####################################################################################################################
        # Prompt for endpoint data or retrieve it from $endpointConfiguration
        #####################################################################################################################
        if($endpointConfiguration -eq $null) {
            if ($endpointName -eq "") {
                do {
                    $endpointName = (Read-Host -prompt "Please enter the $exportOrImport endpoint name").trim()
                }while ($endpointName -eq "")
            }

            do {
                $azureAccountName = (Read-Host -prompt "Please enter the Azure storage account name").trim()
            }while ($azureAccountName -eq "")

            $msg = "INFO: Azure storage account name is '$azureAccountName'."
            Write-Host $msg
            Log-Write -Message $msg

            do {
                $secretKey = (Read-Host -prompt "Please enter the Azure storage account access key ")
            }while ($secretKey -eq "")

            $msg = "INFO: Azure storage account access key is '$secretKey'."
            Write-Host $msg
            Log-Write -Message $msg

            #####################################################################################################################
            # Create endpoint. 
            #####################################################################################################################

            $azureFileSystemConfiguration = New-Object -TypeName 'ManagementProxy.ManagementService.AzureConfiguration' -Property @{  
                "UseAdministrativeCredentials" = $true;         
                "AdministrativeUsername" = $azureAccountName; #Azure Storage Account Name        
                "AccessKey" = $secretKey; #Azure Storage Account SecretKey         
                "ContainerName" = $ContainerName #Container Name
            }
        }
        else {
            $azureFileSystemConfiguration = New-Object -TypeName 'ManagementProxy.ManagementService.AzureConfiguration' -Property @{  
                "UseAdministrativeCredentials" = $true;         
                "AdministrativeUsername" = $endpointConfiguration.AdministrativeUsername; #Azure Storage Account Name        
                "AccessKey" = $endpointConfiguration.AccessKey; #Azure Storage Account SecretKey         
                "ContainerName" = $endpointConfiguration.ContainerName #Container Name
            }
        }
        try {
            $checkEndpoint = Get-BT_Endpoint -Ticket $CustomerTicket -Name $endpointName -Type $endpointType -IsDeleted False -IsArchived False 

            if( $($checkEndpoint.Count -eq 0)) {

                $endpoint = Add-BT_Endpoint -Ticket $customerTicket -Name $endpointName -Type $endpointType -Configuration $azureFileSystemConfiguration 

                $msg = "SUCCESS: The $exportOrImport $endpointType endpoint '$endpointName' created."
                Write-Host -ForegroundColor Green $msg
                Log-Write -Message $msg

                Return $endpoint.Id
            }
            else {
                $msg = "WARNING: $endpointType endpoint '$endpointName' already exists. Skipping endpoint creation."
                Write-Host -ForegroundColor Yellow $msg
                Log-Write -Message $msg

                Return $checkEndpoint.Id
            }
            

        }
        catch {
            $msg = "         ERROR: Failed to create the $exportOrImport $endpointType endpoint '$endpointName'."
            Write-Host -ForegroundColor Red  $msg
            Log-Write -Message $msg
            Write-Host -ForegroundColor Red $_.Exception.Message
            Log-Write -Message $_.Exception.Message
        }    
    }
    elseif($endpointType -eq "AzureSubscription"){
           
        #####################################################################################################################
        # Prompt for endpoint data or retrieve it from $endpointConfiguration
        #####################################################################################################################
        if($endpointConfiguration -eq $null) {
            if ($endpointName -eq "") {
                do {
                    $endpointName = (Read-Host -prompt "Please enter the $exportOrImport endpoint name").trim()
                }while ($endpointName -eq "")
            }

            do {
                $adminUsername = (Read-Host -prompt "Please enter the admin email address").trim()
            }while ($adminUsername -eq "")
        
            $msg = "INFO: Admin email address is '$adminUsername'."
            Write-Host $msg
            Log-Write -Message $msg

            do {
                $adminPassword = (Read-Host -prompt "Please enter the admin password").trim()
            }while ($secretKey -eq "")
        
            $msg = "INFO: Admin password is '$adminPassword'."
            Write-Host $msg
            Log-Write -Message $msg

            do {
                $azureSubscriptionID = (Read-Host -prompt "Please enter the Azure subscription ID").trim()
            }while ($azureSubscriptionID -eq "")

            $msg = "INFO: Azure subscription ID is '$azureSubscriptionID'."
            Write-Host $msg
            Log-Write -Message $msg

            #####################################################################################################################
            # Create endpoint. 
            #####################################################################################################################

            $azureSubscriptionConfiguration = New-Object -TypeName 'ManagementProxy.ManagementService.AzureSubscriptionConfiguration' -Property @{  
                "UseAdministrativeCredentials" = $true;         
                "AdministrativeUsername" = $adminUsername;     
                "AdministrativePassword" = $adminPassword;         
                "SubscriptionID" = $azureSubscriptionID
            }
        }
        else {
            $azureSubscriptionConfiguration = New-Object -TypeName 'ManagementProxy.ManagementService.AzureSubscriptionConfiguration' -Property @{  
                "UseAdministrativeCredentials" = $true;         
                "AdministrativeUsername" = $endpointConfiguration.AdministrativeUsername;  
                "AdministrativePassword" = $endpointConfiguration.AdministrativePassword;    
                "SubscriptionID" = $endpointConfiguration.SubscriptionID 
            }
        }
        try {
            $checkEndpoint = Get-BT_Endpoint -Ticket $CustomerTicket -Name $endpointName -Type $endpointType -IsDeleted False -IsArchived False 

            if( $($checkEndpoint.Count -eq 0)) {

                $endpoint = Add-BT_Endpoint -Ticket $customerTicket -Name $endpointName -Type $endpointType -Configuration $azureSubscriptionConfiguration 

                $msg = "SUCCESS: The $exportOrImport $endpointType endpoint '$endpointName' created."
                Write-Host -ForegroundColor Green $msg
                Log-Write -Message $msg

                Return $endpoint.Id
            }
            else {
                $msg = "WARNING: $endpointType endpoint '$endpointName' already exists. Skipping endpoint creation."
                Write-Host -ForegroundColor Yellow $msg
                Log-Write -Message $msg

                Return $checkEndpoint.Id
            }
            

        }
        catch {
            $msg = "         ERROR: Failed to create the $exportOrImport $endpointType endpoint '$endpointName'."
            Write-Host -ForegroundColor Red  $msg
            Log-Write -Message $msg
            Write-Host -ForegroundColor Red $_.Exception.Message
            Log-Write -Message $_.Exception.Message
        }   
    }
    elseif($endpointType -eq "Pst"){

        #####################################################################################################################
        # Prompt for endpoint data or retrieve it from $endpointConfiguration
        #####################################################################################################################
        if($endpointConfiguration -eq $null) {
            if ($endpointName -eq "") {
                do {
                    $endpointName = (Read-Host -prompt "Please enter the $exportOrImport endpoint name").trim()
                }while ($endpointName -eq "")
            }

             do {
                $azureAccountName = (Read-Host -prompt "Please enter the Azure storage account name").trim()
            }while ($azureAccountName -eq "")

            $msg = "INFO: Azure storage account name is '$azureAccountName'."
            Write-Host $msg
            Log-Write -Message $msg

            do {
                $secretKey = (Read-Host -prompt "Please enter the Azure storage account access key ")
            }while ($secretKey -eq "")


            do {
                $containerName = (Read-Host -prompt "Please enter the container name").trim()
            }while ($containerName -eq "")

            $msg = "INFO: Azure subscription ID is '$containerName'."
            Write-Host $msg
            Log-Write -Message $msg

            #####################################################################################################################
            # Create endpoint. 
            #####################################################################################################################

            $azureSubscriptionConfiguration = New-Object -TypeName 'ManagementProxy.ManagementService.AzureConfiguration' -Property @{  
                "UseAdministrativeCredentials" = $true;         
                "AdministrativeUsername" = $azureAccountName;     
                "AccessKey" = $secretKey;  
                "ContainerName" = $containerName;       
            }
        }
        else {
            $azureSubscriptionConfiguration = New-Object -TypeName 'ManagementProxy.ManagementService.AzureConfiguration' -Property @{  
                "UseAdministrativeCredentials" = $true;         
                "AdministrativeUsername" = $endpointConfiguration.AdministrativeUsername;  
                "AccessKey" = $endpointConfiguration.AccessKey;    
                "ContainerName" = $endpointConfiguration.ContainerName 
            }
        }
        try {
            $checkEndpoint = Get-BT_Endpoint -Ticket $CustomerTicket -Name $endpointName -Type $endpointType -IsDeleted False -IsArchived False 

            if( $($checkEndpoint.Count -eq 0)) {

                $endpoint = Add-BT_Endpoint -Ticket $customerTicket -Name $endpointName -Type $endpointType -Configuration $azureSubscriptionConfiguration 

                $msg = "SUCCESS: The $exportOrImport $endpointType endpoint '$endpointName' created."
                Write-Host -ForegroundColor Green $msg
                Log-Write -Message $msg

                Return $endpoint.Id
            }
            else {
                $msg = "WARNING: $endpointType endpoint '$endpointName' already exists. Skipping endpoint creation."
                Write-Host -ForegroundColor Yellow $msg
                Log-Write -Message $msg

                Return $checkEndpoint.Id
            }
            

        }
        catch {
            $msg = "         ERROR: Failed to create the $exportOrImport $endpointType endpoint '$endpointName'."
            Write-Host -ForegroundColor Red  $msg
            Log-Write -Message $msg
            Write-Host -ForegroundColor Red $_.Exception.Message
            Log-Write -Message $_.Exception.Message
        }  
    }
    elseif($endpointType -eq "OneDriveProAPI"){

        #####################################################################################################################
        # Prompt for endpoint data. 
        #####################################################################################################################
        if($endpointConfiguration -eq $null) {
            if ($endpointName -eq "") {
                do {
                    $endpointName = (Read-Host -prompt "Please enter the $exportOrImport endpoint name").trim()
                }while ($endpointName -eq "")
            }

            do {
                $adminUsername = (Read-Host -prompt "Please enter the admin email address").trim()
            }while ($adminUsername -eq "")
        
            $msg = "INFO: Admin email address is '$adminUsername'."
            Write-Host $msg
            Log-Write -Message $msg

            do {
                $adminPassword = (Read-Host -prompt "Please enter the admin password").trim()
            }while ($secretKey -eq "")
        
            $msg = "INFO: Admin password is '$adminPassword'."
            Write-Host $msg
            Log-Write -Message $msg

            do {
                $azureAccountName = (Read-Host -prompt "Please enter the Azure storage account name").trim()
            }while ($azureAccountName -eq "")
        
            $msg = "INFO: Azure storage account name is '$azureAccountName'."
            Write-Host $msg
            Log-Write -Message $msg

            do {
                $secretKey = (Read-Host -prompt "Please enter the Azure storage account access key").trim()
            }while ($secretKey -eq "")
        
            $msg = "INFO: Azure storage account access key is '$secretKey'."
            Write-Host $msg
            Log-Write -Message $msg
    
            #####################################################################################################################
            # Create endpoint. 
            #####################################################################################################################

            $oneDriveProAPIConfiguration = New-Object -TypeName 'ManagementProxy.ManagementService.SharePointOnlineConfiguration' -Property @{              
                "UseAdministrativeCredentials" = $true;
                "AdministrativeUsername" = $adminUsername;
                "AdministrativePassword" = $adminPassword;
                "AzureStorageAccountName" = $azureAccountName;
                "AzureAccountKey" = $secretKey
            }
        }
        else {
            $oneDriveProAPIConfiguration = New-Object -TypeName 'ManagementProxy.ManagementService.SharePointOnlineConfiguration' -Property @{              
                "UseAdministrativeCredentials" = $true;
                "AdministrativeUsername" = $endpointConfiguration.AdministrativeUsername;
                "AdministrativePassword" = $endpointConfiguration.AdministrativePassword;
                "AzureStorageAccountName" = $endpointConfiguration.AzureStorageAccountName;
                "AzureAccountKey" = $endpointConfiguration.AzureAccountKey
            }
        }

        try {

            $checkEndpoint = Get-BT_Endpoint -Ticket $CustomerTicket -Name $endpointName -Type $endpointType -IsDeleted False -IsArchived False 

            if( $($checkEndpoint.Count -eq 0)) {

                $endpoint = Add-BT_Endpoint -Ticket $CustomerTicket -Name $endpointName -Type $endpointType -Configuration $oneDriveProAPIConfiguration

                $msg = "SUCCESS: The $exportOrImport $endpointType endpoint '$endpointName' created."
                Write-Host -ForegroundColor Green $msg
                Log-Write -Message $msg

                Return $endpoint.Id
            }
            else {
                $msg = "WARNING: $endpointType endpoint '$endpointName' already exists. Skipping endpoint creation."
                Write-Host -ForegroundColor Yellow $msg
                Log-Write -Message $msg

                Return $checkEndpoint.Id
            }

        }
        catch {
            $msg = "         ERROR: Failed to create the $exportOrImport $endpointType endpoint '$endpointName'."
            Write-Host -ForegroundColor Red  $msg
            Log-Write -Message $msg
            Write-Host -ForegroundColor Red $_.Exception.Message
            Log-Write -Message $_.Exception.Message               
        }
    }
    elseif($endpointType -eq "Office365Groups") {

        #####################################################################################################################
        # Prompt for endpoint data. 
        #####################################################################################################################
        if($endpointConfiguration -eq $null) {
            if ($endpointName -eq "") {
                do {
                    $endpointName = (Read-Host -prompt "Please enter the $exportOrImport endpoint name").trim()
                }while ($endpointName -eq "")
            }

            do {
                $url = (Read-Host -prompt "Please enter the Office 365 group URL").trim()
            }while ($url -eq "")
        
            $msg = "INFO: Office 365 group URL is '$url'."
            Write-Host $msg
            Log-Write -Message $msg
        
        
            do {
                $adminUsername = (Read-Host -prompt "Please enter the admin email address").trim()
            }while ($adminUsername -eq "")
        
            $msg = "INFO: Admin email address is '$adminUsername'."
            Write-Host $msg
            Log-Write -Message $msg

            do {
                $adminPassword = (Read-Host -prompt "Please enter the admin password").trim()
            }while ($secretKey -eq "")
        
            $msg = "INFO: Admin password is '$adminPassword'."
            Write-Host $msg
            Log-Write -Message $msg

            #####################################################################################################################
            # Create endpoint. 
            #####################################################################################################################

            $office365GroupsConfiguration = New-Object -TypeName "ManagementProxy.ManagementService.SharePointConfiguration" -Property @{
                "Url" = $url;
                "UseAdministrativeCredentials" = $true;
                "AdministrativeUsername" = $adminUsername;
                "AdministrativePassword" = $adminPassword
            }
        }
        else {
            $office365GroupsConfiguration = New-Object -TypeName "ManagementProxy.ManagementService.SharePointConfiguration" -Property @{
                "Url" = $endpointConfiguration.Url;
                "UseAdministrativeCredentials" = $true;
                "AdministrativeUsername" = $endpointConfiguration.AdministrativeUsername;
                "AdministrativePassword" = $endpointConfiguration.AdministrativePassword
            }
        }

        try {
            
            $checkEndpoint = Get-BT_Endpoint -Ticket $CustomerTicket -Name $endpointName -Type $endpointType -IsDeleted False -IsArchived False 

            if( $($checkEndpoint.Count -eq 0)) {

                $endpoint = Add-BT_Endpoint -Ticket $CustomerTicket -Name $endpointName -Type $endpointType -Configuration $office365GroupsConfiguration

                $msg = "SUCCESS: The $exportOrImport $endpointType endpoint '$endpointName' created."
                Write-Host -ForegroundColor Green $msg
                Log-Write -Message $msg

                Return $endpoint.Id
            }
            else {
                $msg = "WARNING: $endpointType endpoint '$endpointName' already exists. Skipping endpoint creation."
                Write-Host -ForegroundColor Yellow $msg
                Log-Write -Message $msg

                Return $checkEndpoint.Id
            }
        }
        catch {
            $msg = "         ERROR: Failed to create the $exportOrImport $endpointType endpoint '$endpointName'."
            Write-Host -ForegroundColor Red  $msg
            Log-Write -Message $msg
            Write-Host -ForegroundColor Red $_.Exception.Message
            Log-Write -Message $_.Exception.Message               
        }
    }
}

# Function to unzip a file
 Function Unzip-File {
    param 
    (      
        [parameter(Mandatory=$true)] [String]$zipfile
    )

    $folderName = (Get-Item $zipfile).Basename
    $fileName = $($zipfile.split("\")[-1])

    $result = New-Item -ItemType directory -Path $folderName -Force 

    try {
        $result = Expand-Archive $zipfile -DestinationPath $folderName -Force

        $msg = "SUCCESS: '$fileName' file unzipped into '$PSScriptRoot\$folderName'."
        Write-Host -ForegroundColor Green $msg
        Log-Write -Message $msg
    }
    catch {
        $msg = "ERROR: Failed to unzip '$fileName' file."
        Write-Host -ForegroundColor Red  $msg
        Log-Write -Message $msg
        Write-Host -ForegroundColor Red $_.Exception.Message
        Log-Write -Message $_.Exception.Message
        Exit
    }
}

# Function to download a file from a URL
Function Download-File {
    param 
    (      
        [parameter(Mandatory=$true)] [String]$url,
        [parameter(Mandatory=$true)] [String]$outFile
    )

    $fileName = $($url.split("/")[-1])
    $folderName = $fileName.split(".")[0]

    $msg = "INFO: Downloading the latest version of '$fileName' agent (~12MB) from BitTitan..."
    Write-Host $msg
    Log-Write -Message $msg

    #Download the latest version of UploaderWiz from BitTitan server
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    try {
        $result = Invoke-WebRequest -Uri $url -OutFile $outFile
        $msg = "SUCCESS: '$fileName' file downloaded into '$PSScriptRoot'."
        Write-Host -ForegroundColor Green $msg
        Log-Write -Message $msg
    }
    catch {
        $msg = "ERROR: Failed to download '$fileName'."
        Write-Host -ForegroundColor Red  $msg
        Log-Write -Message $msg   
    }

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    Unzip-File $outFile 

    #Open the zip file 
    try {
    
            Start-Process -FilePath "$PSScriptRoot\$folderName"


        }
        catch {
            $msg = "ERROR: Failed to open '$PSScriptRoot' folder."
            Write-Host -ForegroundColor Red  $msg
            Log-Write -Message $msg
            Write-Host -ForegroundColor Red $_.Exception.Message
            Log-Write -Message $_.Exception.Message
            Exit
        }

    
   # else {
   #     $msg = 
   #     "ERROR: Failed to download  UploaderWiz agent from BitTitan."
   #     Write-Host -ForegroundColor Red  $msg
   #     Log-Write -Message $msg
   # }
 
 }

# Function to check if AzureRM is installed
Function Check-AzureRM {
     Try {
        $result = get-module -ListAvailable -name AzureRM -ErrorAction Stop
        if ($result) {
            $msg = "INFO: Ready to execute Azure PowerShell module $($result.moduletype), $($result.version), $($result.name)"
            Write-Host $msg
            Log-Write -Message $msg
        }
        Else {
            $msg = "INFO: AzureRM module is not installed."
            Write-Host -ForegroundColor Red $msg
            Log-Write -Message $msg

            Install-Module AzureRM
            Import-Module AzureRM

            Try {
                
                $result = get-module -ListAvailable -name AzureRM -ErrorAction Stop
                
                If ($result) {
                    write-information "INFO: Ready to execute PowerShell module $($result.moduletype), $($result.version), $($result.name)"
                }
                Else {
                    $msg = "ERROR: Failed to install and import the AzureRM module. Script aborted."
                    Write-Host -ForegroundColor Red  $msg
                    Log-Write -Message $msg   
                    Write-Host -ForegroundColor Red $_.Exception.Message
                    Log-Write -Message $_.Exception.Message
                    Exit
                }
            }
            Catch {
                $msg = "ERROR: Failed to check if the AzureRM module is installed. Script aborted."
                Write-Host -ForegroundColor Red  $msg
                Log-Write -Message $msg   
                Write-Host -ForegroundColor Red $_.Exception.Message
                Log-Write -Message $_.Exception.Message
                Exit
            }
        }

    }
    Catch {
        $msg = "ERROR: Failed to check if the AzureRM module is installed. Script aborted."
        Write-Host -ForegroundColor Red  $msg
        Log-Write -Message $msg   
        Write-Host -ForegroundColor Red $_.Exception.Message
        Log-Write -Message $_.Exception.Message
        Exit
    } 
}

# Function to connect to Azure
Function Connect-Azure{
    param(
        [Parameter(Mandatory=$true)] [PSObject]$azureCredentials,
        [Parameter(Mandatory=$false)] [String]$subscriptionID
    )

    $msg = "INFO: Connecting to Azure to create a blob container."
    Write-Host $msg
    Log-Write -Message $msg
    Try {
        if($subscriptionID -eq $null) {
            $result = Login-AzureRMAccount -Credential $azureCredentials -Environment "AzureCloud" -ErrorAction Stop
        }
        else {
            $result = Login-AzureRMAccount -Credential $azureCredentials -Environment "AzureCloud" -SubscriptionId $subscriptionID -ErrorAction Stop
        }

        $azureAccount = (Get-AzureRmContext).Account
        $subscriptionName = (Get-AzureRmSubscription -SubscriptionID $subscriptionID).Name
        $msg = "SUCCESS: Connection to Azure: Account: $azureAccount Subscription: '$subscriptionName'."
        Write-Host -ForegroundColor Green  $msg
        Log-Write -Message $msg
    }
    catch {
        $msg = "ERROR: Failed to connect to Azure. Script aborted."
        Write-Host -ForegroundColor Red  $msg
        Log-Write -Message $msg
        Write-Host -ForegroundColor Red $_.Exception.Message
        Log-Write -Message $_.Exception.Message
        Exit
    }

}

# Function to check if a StorageAccount exists
Function Check-StorageAccount{
    param 
    (      
        [parameter(Mandatory=$true)] [String]$storageAccountName
    )   

    try {
        $storageAccount = Get-AzureRmStorageAccount -ErrorAction Stop |? {$_.StorageAccountName -eq $storageAccountName}

        $msg = "SUCCESS: Azure storage account '$storageAccountName' found."
        Write-Host -ForegroundColor Green  $msg
        Log-Write -Message $msg   

        if($storageAccount ){
            Return $storageAccount
        }
        else {
            Return $false
        }
    }
    catch {
        $msg = "ERROR: Failed to find the Azure storage account '$storageAccountName'. Script aborted."
        Write-Host -ForegroundColor Red  $msg
        Log-Write -Message $msg   
        Write-Host -ForegroundColor Red $_.Exception.Message
        Log-Write -Message $_.Exception.Message
        Exit

    }
}

# Function to check if a blob container exists
Function Check-BlobContainer{
    param 
    (      
        [parameter(Mandatory=$true)] [String]$blobContainerName,
        [parameter(Mandatory=$true)] [PSObject]$storageAccount
    )   

    try {
        $result = Get-AzureStorageContainer -Name $blobContainerName -Context $storageAccount.Context -ErrorAction SilentlyContinue

        if($result){
            $msg = "SUCCESS: Blob container '$($blobContainerName)' found under the Storage account '$($storageAccount.StorageAccountName)'."
            Write-Host -ForegroundColor Green $msg
            Log-Write -Message $msg  
            Return $true
        }
        else {
            Return $false
        }
    }
    catch {
        $msg = "ERROR: Failed to get the blob container '$($blobContainerName)' under the Storage account '$($storageAccount.StorageAccountName)'. Script aborted."
        Write-Host -ForegroundColor Red  $msg
        Log-Write -Message $msg   
        Write-Host -ForegroundColor Red $_.Exception.Message
        Log-Write -Message $_.Exception.Message
        Exit

    }
}

# Function to create a Blob Container
Function Create-BlobContainer{
    param 
    (      
        [parameter(Mandatory=$true)] [String]$blobContainerName,
        [parameter(Mandatory=$true)] [PSObject]$storageAccount,
        [parameter(Mandatory=$false)] [Boolean]$permissionsOff
    )   

    try {
        if($permissionsOff) {
            $result = New-AzureStorageContainer -Name $blobContainerName -Context $storageAccount.Context -Permission Off -ErrorAction Stop
        }
        else {
            $result = New-AzureStorageContainer -Name $blobContainerName -Context $storageAccount.Context -ErrorAction Stop        
        }

        $msg = "SUCCESS: Blob container '$($blobContainerName)' created under the Storage account '$($storageAccount.StorageAccountName)'."
        Write-Host -ForegroundColor Green  $msg
        Log-Write -Message $msg   
    }
    catch {
        $msg = "ERROR: Failed to create blob container '$($blobContainerName)' under the Storage account '$($storageAccount.StorageAccountName)'. Script aborted."
        Write-Host -ForegroundColor Red  $msg
        Log-Write -Message $msg   
        Write-Host -ForegroundColor Red $_.Exception.Message
        Log-Write -Message $_.Exception.Message
        Exit

    }

}

Function Check-FileShare {
    param 
    (      
        [parameter(Mandatory=$true)] [String]$FileShareName,
        [parameter(Mandatory=$true)] [PSObject]$storageAccount
    )   

    try {
        $result = Get-AzureStorageShare -Name $FileShareName -Context $storageAccount.Context -ErrorAction SilentlyContinue

        if($result){
            $msg = "SUCCESS: File Share '$($FileShareName)' found under the Storage account '$($storageAccount.StorageAccountName)'."
            Write-Host -ForegroundColor Green $msg
            Log-Write -Message $msg  
            Return $true
        }
        else {
            Return $false
        }
    }
    catch {
        $msg = "ERROR: Failed to get the File Share '$($FileShareName)' under the Storage account '$($storageAccount.StorageAccountName)'. Script aborted."
        Write-Host -ForegroundColor Red  $msg
        Log-Write -Message $msg   
        Write-Host -ForegroundColor Red $_.Exception.Message
        Log-Write -Message $_.Exception.Message
        Exit

    }

}

Function Create-FileShare {
    param 
    (      
        [parameter(Mandatory=$true)] [String]$FileShareName,
        [parameter(Mandatory=$true)] [PSObject]$storageAccount
    )   

    try {
        $result = New-AzureStorageShare -Name $FileShareName -Context $storageAccount.Context -ErrorAction Stop

        $msg = "SUCCESS: File Share '$($FileShareName)' created under the Storage account '$($storageAccount.StorageAccountName)'."
        Write-Host -ForegroundColor Green  $msg
        Log-Write -Message $msg   
    }
    catch {
        $msg = "ERROR: Failed to create File Share '$($FileShareName)' under the Storage account '$($storageAccount.StorageAccountName)'. Script aborted."
        Write-Host -ForegroundColor Red  $msg
        Log-Write -Message $msg   
        Write-Host -ForegroundColor Red $_.Exception.Message
        Log-Write -Message $_.Exception.Message
        Exit

    }

    #Calculate the connection strings
    try {
        $AzureSAKey = Get-AzureRmStorageAccountKey -Name $storageAcct.StorageAccountName -ResourceGroupName $storageAcct.ResourceGroupName -ErrorAction Stop | Select-Object -first 1
        
        $StorageAccountKey = $AzureSAKey.Value

        $FileShareUNCPathOutput = "\\$($storageAcct.StorageAccountName).file.core.windows.net\$($result.Name)"

        $FileShareConnectionStringOutput = "net use z: \\$($storageAcct.StorageAccountName).file.core.windows.net\$($result.Name) /u:AZURE\$($storageAcct.StorageAccountName) $($StorageAccountKey)"
    }
    Catch {
        $msg = "ERROR: Failed to get the connection string. Script aborted."
        Write-Host -ForegroundColor Red  $msg
        Log-Write -Message $msg   
        Write-Host -ForegroundColor Red $_.Exception.Message
        Log-Write -Message $_.Exception.Message
    }


}

Function Create-SASToken {
    param 
    (      
        [parameter(Mandatory=$true)] [String]$blobContainerName,
        [parameter(Mandatory=$false)] [String]$BlobName,
        [parameter(Mandatory=$true)] [PSObject]$storageAccount,
        [parameter(Mandatory=$true)] [String]$permissions,
        [parameter(Mandatory=$true)] [String]$hours
    )   

    #-Permission "racwdlup" read,add,create,write,delete,list

    $StartTime = Get-Date
    $EndTime = $startTime.AddHours($hours) #1 week

    # Read access - https://docs.microsoft.com/en-us/powershell/module/azure.storage/new-azurestoragecontainersastoken
    $SasToken = New-AzureStorageContainerSASToken -Name $blobContainerName -Protocol HttpsOnly  `
    -Context $storageAccount.Context -Permission $permissions -StartTime $StartTime -ExpiryTime $EndTime
    $SasToken | clip

    Return $SasToken

}

# Function to wait for the user to press any key to continue
Function WaitForKeyPress{
    $msg = "ACTION: If you have edited and saved the CSV file then press any key to continue." 
    Write-Host $msg
    Log-Write -Message $msg
    $null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown');
}

Function Get-FileName($initialDirectory) {
    [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null
    
    $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
    $OpenFileDialog.initialDirectory = $initialDirectory
    $OpenFileDialog.filter = "CSV (*.csv)| *.csv"
    $OpenFileDialog.ShowDialog() | Out-Null
    $script:inputFile = $OpenFileDialog.filename

    if($OpenFileDialog.filename -ne "") {		    
        $msg = "SUCCESS: CSV file '$($OpenFileDialog.filename)' selected."
        Write-Host -ForegroundColor Green  $msg
        Log-Write -Message $msg
    }
}

Function Get-CsvFile {
    Write-Host
    Write-Host -ForegroundColor yellow "ACTION: Select the CSV file to import the user email addresses."
    Get-FileName $workingDir

    # Import CSV and validate if headers are according the requirements
    try {
        $lines = @(Import-Csv $script:inputFile)
    }
    catch {
        $msg = "ERROR: Failed to import '$script:inputFile' CSV file. Script aborted."
        Write-Host -ForegroundColor Red  $msg
        Log-Write -Message $msg
        Write-Host -ForegroundColor Red $_.Exception.Message
        Log-Write -Message $_.Exception.Message
        Exit   
    }

    # Validate if CSV file is empty
    if ( $lines.count -eq 0 ) {
        $msg = "ERROR: '$script:inputFile' CSV file exist but it is empty. Script aborted."
        Write-Host -ForegroundColor Red  $msg
        Log-Write -Message $msg
        Exit
    }

    # Validate CSV Headers
    $CSVHeaders = "UserEmailAddress,FirstName"
    foreach ($header in $CSVHeaders) {
        if ($lines.$header -eq "" ) {
            $msg = "ERROR: '$script:inputFile' CSV file does not have all the required columns. Required columns are: '$($CSVHeaders -join "', '")'. Script aborted."
            Write-Host -ForegroundColor Red  $msg
            Log-Write -Message $msg
            Exit
        }
    }

    Return $lines
 
 }

 #######################################################################################################################
#                                               MAIN PROGRAM
#######################################################################################################################

#Working Directory
$workingDir = "C:\scripts"

#Logs directory
$logDirName = "LOGS"
$logDir = "$workingDir\$logDirName"

#Log file
$logFileName = "$(Get-Date -Format yyyyMMdd)_Upload-UW_PstToAzureBlobContainer.log"
$logFile = "$logDir\$logFileName"

Create-Working-Directory -workingDir $workingDir -logDir $logDir

Write-Host 
Write-Host -ForegroundColor Yellow "WARNING: Minimal output will appear on the screen." 
Write-Host -ForegroundColor Yellow "         Please look at the log file '$($logFile)'."
Write-Host -ForegroundColor Yellow "         Generated CSV file will be in folder '$($workingDir)'."
Write-Host 
Start-Sleep -Seconds 1

$msg = "++++++++++++++++++++++++++++++++++++++++ SCRIPT STARTED ++++++++++++++++++++++++++++++++++++++++"
Log-Write -Message $msg

$msg = "INFO: Connecting to MSPComplete to retrieve the 2 endpoints (AzureSubscription, Pst) to connect to Azure."
Write-Host $msg
Log-Write -Message $msg

# Authenticate
$creds = Get-Credential -Message "Enter BitTitan credentials"
# Get a ticket and set it as default
$ticket = Get-BT_Ticket -Credentials $creds -ServiceType BitTitan -SetDefault -ErrorAction SilentlyContinue
# Get a MW ticket
$global:mwTicket = Get-MW_Ticket -Credentials $creds -ErrorAction SilentlyContinue

if(!$ticket -or !$global:mwTicket) {
    $msg = "ERROR: Failed to create ticket. Script aborted."
    Write-Host -ForegroundColor Red  $msg
    Log-Write -Message $msg
    Write-Host
    Write-Host -ForegroundColor Red $error[0]
    Log-Write -Message $error[0]  

    Exit
}

#Select workgroup
$WorkgroupId = Select-MSPC_WorkGroup

#Select customer
$customerId = Select-MSPC_Customer -Workgroup $WorkgroupId

#Select source endpoint
$azureSubscriptionEndpointId = Select-MSPC_Endpoint -CustomerId $customerId -EndpointType "AzureSubscription"
#Get source endpoint credentials
[PSObject]$azureSubscriptionEndpointData = Get-MSPC_EndpointData -CustomerId $customerId -EndpointId $azureSubscriptionEndpointId 

#Create a PSCredential object to connect to Azure Active Directory tenant
$administrativeUsername = $azureSubscriptionEndpointData.AdministrativeUsername
$administrativePassword = ConvertTo-SecureString -String $($azureSubscriptionEndpointData.AdministrativePassword) -AsPlainText -Force
$azureCredentials = New-Object System.Management.Automation.PSCredential ($administrativeUsername, $administrativePassword)

#Select source endpoint
$exportEndpointId = Select-MSPC_Endpoint -CustomerId $customerId -ExportOrImport "source" -EndpointType "Pst"
#Get source endpoint credentials
[PSObject]$exportEndpointData = Get-MSPC_EndpointData -CustomerId $customerId -EndpointId $exportEndpointId 

Write-Host
# AzureRM module installation
Check-AzureRM
# Azure log in
Connect-Azure -AzureCredentials $azureCredentials -SubscriptionID $azureSubscriptionEndpointData.SubscriptionID
#Azure storage account
$storageAccount = Check-StorageAccount -StorageAccountName $exportEndpointData.AdministrativeUsername
# Azure blob container
if(!$exportEndpointData.ContainerName){
    $container = "migrationwizpst"
}
$result = Check-BlobContainer -BlobContainerName "migrationwizpst" -StorageAccount $storageAccount

if(!$result) {
    Create-BlobContainer -BlobContainerName $container -StorageAccount $storageAccount
}

$SasToken = Create-SASToken -BlobContainerName $container -StorageAccount $storageAccount -permissions "w" -hours "168.0" #720 hours = 1 month




$disconnectPSTs = "powershell `"Write-host 'Disconnecting all PST files from your Outlook.';`$Outlook = New-Object -ComObject Outlook.Application;`$Namespace = `$Outlook.getNamespace('MAPI');`$all_psts = `$Namespace.Stores | Where-Object {(`$_.ExchangeStoreType -eq '3') -and (`$_.FilePath -like '*.pst') -and (`$_.IsDataFileStore -eq `$true)}; ForEach (`$pst in `$all_psts){`$Outlook.Session.RemoveStore(`$pst.GetRootFolder());}`" "

$downloadUploaderWiz = 'bitsadmin /transfer PST_Migration /download /priority normal "https://api.bittitan.com/secure/downloads/UploaderWiz.zip" "c:\BitTitan\UploaderWiz.zip"'

$unzipUploaderWiz = "powershell Expand-Archive c:\BitTitan\UploaderWiz.zip  -DestinationPath c:\BitTitan\UploaderWiz\ -force" 

$uploaderwizCommand = "UploaderWiz.exe -type azureblobs -accesskey " + $CH34 + $exportEndpointData.AdministrativeUsername + $CH34 + " -secretkey " + $CH34 + $exportEndpointData.AccessKey + $CH34 + " -token " + $CH34 + $SasToken + $CH34 + " -container "+ $container + " -autodiscover true -interactive false -filefilter " + $CH34 + " *.pst" + $CH34 + " -force True"

$startUploaderWiz = "START C:\BitTitan\UploaderWiz\$uploaderwizCommand"

$batchFileCode = "@echo off`r`n`r`n$disconnectPSTs`r`n`r`n$downloadUploaderWiz`r`n`r`n$unzipUploaderWiz`r`n`r`n$startUploaderWiz`r`n"

$batFile = "C:\scripts\Migrate_PST_Files.bat"
Set-Content -Path $batFile -Value $batchFileCode -Encoding ASCII

# Azure FileShare
$result = Check-BlobContainer -BlobContainerName "batchfile" -StorageAccount $storageAccount

if(!$result) {
    Create-BlobContainer -BlobContainerName "batchfile" -StorageAccount $storageAccount -PermissionsOff  $true
}

# upload the batch file
$blobContainerName = "batchfile"
$BlobName = "migratePstFiles.bat"
$result = Set-AzureStorageBlobContent -File $batFile -Container $blobContainerName -Blob $BlobName -Context $storageAccount.context -force
 
$SasToken = Create-SASToken -BlobContainerName "batchfile" -BlobName "migratePstFiles.bat" -StorageAccount $storageAccount -permissions "rl" -hours "168.0" #168 hours = 1 week

# Construct the URL & Test
$url = "$($storageAccount.Context.BlobEndPoint)$($blobContainerName)/$($BlobName)$($SasToken)"
$url | clip

Write-Host
$msg = "SUCCESS: Batch file '$batFile' created to be sent to all end users for them to manually run it for PST file automated migration."
Write-Host  -ForegroundColor Green $msg
Log-Write -Message $msg
write-host
$msg = "++++++++++++++++++++++++++++++++++++++++ BATCH FILE: Migrate_PST_files.bat  ++++++++++++++++++++++++++++++++++++++++`n"
write-host $msg
Log-Write -Message $msg

write-host $batchFileCode
Log-Write -Message $batchFileCode

$msg = "++++++++++++++++++++++++++++++++++++++++++++++++ END BATCH FILE ++++++++++++++++++++++++++++++++++++++++++++++++++++`n"
write-host $msg
Log-Write -Message $msg

$applyCustomFolderMapping = $false
do {
    $confirm = (Read-Host -prompt "Do you want to send the .bat file to all your users?  [Y]es or [N]o").trim()

    if($confirm.ToLower() -eq "y") {
        $sendBatchFile = $true        
    }

} while(($confirm.ToLower() -ne "y") -and ($confirm.ToLower() -ne "n"))

if($sendBatchFile) {

    $users = Get-CsvFile
    Write-Host
    $msg = "ACTION: Provide your Office 365 admin credentials to send the emails."
    Write-Host -ForegroundColor Yellow $msg
    Log-Write -Message $msg

    $smtpCreds = Get-Credential -Message "Enter Office 365 credentials"

    Write-Host
    foreach ($user in $users) {
        
        $msg = "INFO: Sending email with .bat file to '$($user.userEmailAddress)'."
        Write-Host $msg
        Log-Write -Message $msg

        #################################################################################
        $smtpServer = "smtp.office365.com"        
        $emailTo = $user.userEmailAddress
        $emailFrom = $smtpCreds.UserName
        $Subject = "Action required: Install the BitTitan UploaderWiz Agent on your computer."

        $body += "<tbody>"
        $body += "<center>"
        $body += "<table>"
        $body += "<tr>"
        $body += "<td align='left' valign='top'>"
        $body += "<p class='x_Logo'><a href='http://www.bittitan.com' target='_blank' rel='noopener noreferrer' data-auth='NotApplicable' title='BitTitan'><img data-imagetype='External' src='https://static.bittitan.com/Images/MSPC/MSPC_banner.png' width='600' height='50' class='x_LogoImg' alt='BitTitan' border='0'> </a></p>"
        $body += "<span style='font-family: Arial, Helvetica, sans-serif, serif, EmojiFont; font-size: 12px; color: rgb(10, 10, 10);'>"
        $body += "<p>Hello $($user.FirstName),</p>"
        $body += "<h3>Important Announcement</h3>"
        $body += "<p>We are currently planning a series of updates and improvements to our IT Services.</p>"
        $body += "<p>We are committed to creating and maintaining the best user experience with these changes. In order to do so, </br>" 
        $body += "so we will need to install an application (the BitTitan UploaderWiz Agent) that will disconnect all your PST files</br>"
        $body += "from you Outlook client and migrate them to your new Office 365 mailbox.</p>"
        $body += "<h3>Actions Required</h3>"
        $body += "<p>Complete the application installation by following these steps:</p>"
        $body += "<ol>"
        $body += "<li>Click on this link: <a href='$url' target='_blank' rel='noopener noreferrer' data-auth='NotApplicable' title='Install BitTitan UploaderWiz Agent'>Install BitTitan UploaderWiz Agent Application</a> `</li><li>Select Run. `</li></ol>"
        $body += "<p>The application will silently install. It will not impact any other work that you are doing.</p>"
        $body += "<p>We will contact you in the coming weeks if we determine that your computer requires any necessary updates.</p>"
        $body += "<hr>"
        $body += "<p>Thank you, $CustomerName IT Department</p>"
        $body += "</span></td>"
        $body += "</tr>"
        $body += "</table>"
        $body += "</td>"
        $body += "</tr>"
        $body += "</center>"
        $body += "</tbody>"
        
        #$attachment = "c:\scripts\Migrate_PST_files.bat.rename"

        #################################################################################

        try {

            $result = Send-MailMessage -To $emailTo -From $emailFrom -Subject $subject -Body $body -BodyAsHtml -SmtpServer $smtpServer -Port 587 -Credential $smtpCreds -UseSsl #-Attachments $attachment 

            if ($error[0].ToString() -match "Spam abuse detected from IP range.") { 
                #5.7.501 Access denied, spam abuse detected. The sending account has been banned due to detected spam activity. 
                #For details, see Fix email delivery issues for error code 451 5.7.500-699 (ASxxx) in Office 365.
                #https://support.office.com/en-us/article/fix-email-delivery-issues-for-error-code-451-4-7-500-699-asxxx-in-office-365-51356082-9fef-4639-a18a-fc7c5beae0c8 
                $msg = "      ERROR: Failed to send email to user '$emailTo'. Access denied, spam abuse detected. The sending account has been banned. "
                Write-Host -ForegroundColor Red  $msg
                Log-Write -Message $msg
            }
            else {
                $msg = "SUCCESS: Email with .bat file sent to end user '$emailTo'"
                Write-Host -ForegroundColor Green $msg
                Log-Write -Message $msg 
           }

        }
        catch {
            $msg = "ERROR: Failed to send email to user '$emailTo'."
            Write-Host -ForegroundColor Red  $msg
            Write-Host -ForegroundColor Red $_.Exception.Message
            Log-Write -Message $msg
            Log-Write -Message $_.Exception.Message
        }
    }
}

try {
    #Open the folder containing the .bat file
    Start-Process -FilePath C:\scripts\
}
catch {
    $msg = "ERROR: Failed to open 'C:\scripts\Migrate_PST_files.bat' batch file."
    Write-Host -ForegroundColor Red  $msg
    Log-Write -Message $msg
    Write-Host -ForegroundColor Red $_.Exception.Message
    Log-Write -Message $_.Exception.Message
    Exit
}

$msg = "++++++++++++++++++++++++++++++++++++++++ SCRIPT FINISHED ++++++++++++++++++++++++++++++++++++++++`n"
Log-Write -Message $msg

##END SCRIPT
